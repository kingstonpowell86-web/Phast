@echo off
echo Starting Frida injection for Meta Game...
echo.

frida -U -l frida-il2cpp-bridge.js -l "LILBIG4DEV_CLIENT_THE_BEST55_V10__1_ (2) - Copy (2).js" "Baboon"

echo.
echo Frida script execution completed.
echo.
pause
echo Closing...